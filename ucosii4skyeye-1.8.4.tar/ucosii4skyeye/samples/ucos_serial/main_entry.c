/*   
 *  hello.c
 *  this file implement start_kernel and irqhandler
 *  for Atmel AT91 operating system
 *
 *  Bugs report:     li ming  ( lmcs00@mails.tsinghua.edu.cn )
 *  Last modified:   2003-02-02 
 *
 */
 
#include "skyeye_stdio.h"
#include "includes.h"
#include "at91_init.h"
#include "serialucos.h"

#define  RCR  0xfffd0034

//yangye (OSTickISR -> OSISR)
extern void UART0ISR(void);
extern void CommRxIntEn(INT8U ch);
extern void OSISR(void);

void Sleep(INT16U uSec);
void Task1(void * pParam);
void Task2(void * pParam);
void Task3(void * pParam);
extern void  OSTimeTick(void);

#define	N_TASKS		3	// Number of tasks
#define	TASK_STK_SIZE	1024		// Stack size, in sizeof OS_STK, or int 32bit
OS_STK	TaskStk[N_TASKS][TASK_STK_SIZE];	// Tasks stacks

char bufchar; 
OS_EVENT *sem1;

/* start_kernel entry */
void start_kernel(void)
{
  	int	task_1 = 1;
	int	task_2 = 2;
	int 	task_3 = 3;
	
	/* firstly, we should install irq mode handler, must call do_irq in any user's handler  */
	install_irqhandler(OSISR);
	//yangye
	request_irq(5,OSTimeTick);
	request_irq(2,UART0ISR);

	OSInit();
	
	OSTaskCreate(Task1, &task_1, &TaskStk[0][TASK_STK_SIZE-1], 0);
	OSTaskCreate(Task2, &task_2, &TaskStk[1][TASK_STK_SIZE-1], 1);
	OSTaskCreate(Task3, &task_3, &TaskStk[2][TASK_STK_SIZE-1], 2);
	
	OSStart();
}

/* Task1 print_user_input */
void Task1(void * pParam)
{		
  char err;	
  at91_init();
  CommInit();
  sem1 = OSSemCreate(0);
  while(1)	
    {
      OSSemPend(sem1,0,&err);   //sleep ,wait for sem1
      skyeye_printf( "Task1 running... Your input char: \"%c\"\n", bufchar );
    }
}


/* Task2 get_user_input */
void Task2(void * pParam)
{
  char err;
  CommRxIntEn(UART0);
  while (1)
    {
      skyeye_printf( "Task2 running... Please input a char:> \n" );
      bufchar = CommGetChar(UART0,0,&err);
      OSSemPost(sem1);
      skyeye_printf("once again: \n");
    }
}

void Task3(void *pParam)
{
  while(1)
    {
     skyeye_printf(" Task3: now it is my turn ,haha! \n");
     skyeye_printf(" Task3: you may input a char to wake up task1 and task2. \n");
     Sleep(500);     
    }
}


/* call system delay function */
void Sleep(INT16U uSec)
{
  OSTimeDly((INT16U) (uSec) * 10);
}

