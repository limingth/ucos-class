

#include "at91.h"
#include "at91_init.h"
#include "includes.h"
#include "serialucos.h"

#define UART0_IRQNUM     2
#define UART1_IRQNUM	 3

#define UART0_BASEADDR  (0xfffd0000)
#define US0_CSR         (UART0_BASEADDR+0x14)
#define US0_RPR         (UART0_BASEADDR+0x30)
#define US0_RCR         (UART0_BASEADDR+0x34)

//yangye 2003-2-19
#define   RX_BUF_SIZE  256
INT8U  receive_buf[256];	 /* the receive buf for US_RPR, only one char */

void UART0ISR(void);
void CommRxIntDis(INT8U ch);
void CommRxIntEn(INT8U ch);

/*
************************************************************************
*                                           COMM ISR HANDLER
*
* Description : This function processes an interrupt from a COMM port.  The function verifies whether the
*               interrupt comes from a received character, the completion of a transmitted character or
*               both.
* Arguments   : 'ch'          is the COMM port channel number and can either be:
*                                 UART0 
*                                 UART1 
**************************************************************************
*/
void  UART0ISR (void)
{
	INT8U    count,c,i;
	INT32U   csr,rcr;                     /* channel status Register  */
  	INT8U   *rx_buf;

	rx_buf = &receive_buf[0];    

	csr =  __arch_getl(US0_CSR);        /* Get contents of  usart0 CSR                 */
	rcr =  __arch_getl(US0_RCR);        
	count = RX_BUF_SIZE - rcr;  //count is the number of input chars
	  
      	if(count > 0) {		
	  for(i=0;i<count;i++){	    
	    c  = *rx_buf++;		       	/* Process received character       */
	    CommPutRxChar(UART0, c);		/* Insert received character into buffer     */ 
	  }
	}
	
	//init UART0 for next receive
	CommRxIntEn(UART0);
	
}

/*
*********************************************************************
*                                         DISABLE RX INTERRUPTS
*
* Description : This function disables the Rx interrupt.
* Arguments   : 'ch'          is the COMM port channel number and can either be:
*                                 UART0 
*                                 UART1 
*********************************************************************
*/

void  CommRxIntDis (INT8U ch)
{
	OS_ENTER_CRITICAL();
		/* Disable Rx interrupts */
	if(ch == UART0)
 	  at91_mask_irq(UART0_IRQNUM);
	
	//else if(ch == UART1)
		//at91_mask_irq(UART1_IRQNUM);

	OS_EXIT_CRITICAL();
}


/*
*****************************************************************************
*                                          ENABLE RX INTERRUPTS
*
* Description : This function enables the Rx interrupt.
* Arguments   : 'ch'          is the COMM port channel number and can either be:
*                                 UART0 
*                                 UART1 
***********************************************************************
*/
void CommRxIntEn(INT8U ch)
{

  OS_ENTER_CRITICAL();
  /* init USART & Enable Rx interrupts 	 */
  if(ch == UART0){
    __arch_putl((unsigned long)RX_BUF_SIZE, US0_RCR);
    __arch_putl((unsigned long)(&receive_buf[0]), US0_RPR);

    at91_unmask_irq(UART0_IRQNUM);
  }
  else if(ch == UART1){
 
  }
  OS_EXIT_CRITICAL();
}
