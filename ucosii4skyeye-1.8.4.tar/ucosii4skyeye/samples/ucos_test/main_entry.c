/*   
 *  hello.c
 *  this file implement start_kernel and irqhandler
 *  for Atmel AT91 operating system
 *
 *  Bugs report:     li ming  ( lmcs00@mails.tsinghua.edu.cn )
 *  Last modified:   2003-02-02 
 *
 */
 
#include "skyeye_stdio.h"
#include "includes.h"
#include "at91_init.h"

//yangye (OSTickISR -> OSISR)
extern void OSISR(void);
void Sleep(INT16U uSec);
void Task1(void * pParam);
void Task2(void * pParam);
extern void  OSTimeTick(void);

#define	N_TASKS			3	// Number of tasks
#define	TASK_STK_SIZE	1024		// Stack size, in sizeof OS_STK, or int 32bit
OS_STK	TaskStk[N_TASKS][TASK_STK_SIZE];	// Tasks stacks
char s[200];
char tmp[200];
OS_EVENT *sem1;
/* start_kernel entry */
void start_kernel(void)
{
	int i;
	int	task_1 = 1;
	int	task_2 = 2;
	for(i=0;i<7;i++)
		s[i] = 'a';
	s[7] = '\n';

	/* firstly, we should install irq mode handler, must call do_irq in any user's handler  */
	install_irqhandler(OSISR);
	//yangye
	request_irq(5,OSTimeTick);

	OSInit();
	
	OSTaskCreate(Task1, &task_1, &TaskStk[0][TASK_STK_SIZE-1], 0);
	OSTaskCreate(Task2, &task_2, &TaskStk[1][TASK_STK_SIZE-1], 1);
	
	OSStart();
}

/* Task1 get_user_input */
void Task1(void * pParam)
{
	at91_init();
	sem1 = OSSemCreate(0);
	while (1)
	{
		skyeye_printf( "Task1 running... Please input a string:> " );
		skyeye_gets(s);
		OSSemPend(sem1,0,(void*)0);
		skyeye_printf("aaaaaaaaaaa");
	}
}

/* Task2 print_user_input */
void Task2(void * pParam)
{		
 	while(1)	
	{
		skyeye_printf( "Task2 running... Your input string: \"%s\"\n", s );	
		OSSemPost(sem1);
	}
}

/* call system delay function */
void Sleep(INT16U uSec)
{
	OSTimeDly((INT16U) (uSec) * 10);
}

