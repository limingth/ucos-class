/*	 
 *	serialucos.h
 *	the serial receive driver for skyeye
 *	(ucosII part) 
 *	
 *	Bugs report:	 Yang Ye  ( yangye@163.net )
 *	Last modified:	 2003-02-19 
 *
 */


#ifndef  SERIAL_UCOS_H
#define  SERIAL_UCOS_H

#define  COMM_RX_BUF_SIZE      64                /* Number of characters in Rx ring buffer             */

#define UART0     0
#define UART1     1

#ifndef  NUL
#define  NUL	0
#endif    
                              
/* ERROR CODES                                   */
#define  COMM_NO_ERR            0                /* Function call was successful                       */
#define  COMM_RX_EMPTY          1                /* Rx buffer is empty, no character available         */
#define  COMM_RX_TIMEOUT        2                /* If a timeout occurred while waiting for a character*/
#define  COMM_BAD_CH            3
/*
*****************************************************
*                  FUNCTION PROTOTYPES
*****************************************************
*/

INT8U    CommGetChar(INT8U ch, INT16U to, INT8U *err);
void     CommInit(void);
BOOLEAN  CommIsEmpty(INT8U ch);
void     CommPutRxChar(INT8U ch, INT8U c);

#endif
