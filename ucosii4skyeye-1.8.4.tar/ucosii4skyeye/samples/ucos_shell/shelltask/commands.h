/*	 
 *	commands.h
 *	the genie shell commands part for ucosII
 *	under skyeye
 *
 *	Bugs report:	 Yang Ye  ( yangye@163.net )
 *	Last modified:	 2003-02-19 
 *
 */

#ifndef COMMANDDEF

#define MAX_COMMAND_NUM    2

typedef struct{
	int num;
	char *name;
	INT8U (*CommandFunc)(INT8U argc,char **argv);
}command;

#endif 

INT8U InitCommands(void);
INT8U HelloFunc(INT8U argc,char **argv);
INT8U HostNameFunc(INT8U argc,char **argv);
	
