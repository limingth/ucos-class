/*	 
 *	shelltask.c
 *	the genie shell task for ucosII
 *	under skyeye
 *
 *	Bugs report:	 Yang Ye  ( yangye@163.net )
 *	Last modified:	 2003-02-19 
 *
 */

#include "skyeye_stdio.h"
#include "includes.h"
#include "at91_init.h"
#include "serialucos.h"
#include "commands.h"
#include "shelltask.h"

extern command ShellComms[MAX_COMMAND_NUM];
extern void CommRxIntEn(INT8U ch);

char *argv[10];
INT8U argc;

void shelltask(void *pParam)
{
INT8U i=0,num,err;		/*i is the pointer of commandbuf */
char ch;
INT8U (*Func)(INT8U argc,char **argv);
char CommandBuf[MaxLenComBuf+1];	/*store '\0'*/
CommRxIntEn(UART0);
InitCommands();
CommandBuf[0] = '\0';

//to do: add some lib functions for ucosII ,like clear screen .
//clrscr();
skyeye_printf("\n\r***********************************************\n");
skyeye_printf("\n\r*         Welcom to genie shell           *\n");
skyeye_printf("\n\r*           Author:YangYe 20021102   	*\n");
skyeye_printf("\n\r***********************************************\n\n");
		
/*To be done: Login & Password*/

skyeye_printf("\n\rYes,master?");

for(;;){
	do{					//only accept a-z,0-9,A-Z,.,space,/,-
	ch = CommGetChar(UART0,0,&err);
	}while(!((ch>='0'&&ch<='9')||(ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')||(ch=='.')||(ch==' ')||(ch=='-')||(ch=='/')||(ch==10)||(ch=='\b')||(ch==',')));
		
	switch(ch)
	{
	case 10:				//enter
		if (i==0){      						//commandbuf is null,begin a new line
			skyeye_printf("\n\rYes,master?");
			}
		else{
			if(CommandBuf[i-1]==' ') 
				i--;			//get rid of the end space
			CommandBuf[i] = '\0';
			num = CommandAnalys(CommandBuf);	//analys the argv in the commandbuf
			if(num==ERRORCOMMAND){             	//error or none exist command
				i = 0;
				CommandBuf[i] = '\0';
				skyeye_printf("\n\rPardon me,master");
				skyeye_printf("\n\rYes,master?");
				}
			else{
				Func = ShellComms[num].CommandFunc;	//call corresponding CommandFunc
				Func(argc,argv);
				i = 0;
				CommandBuf[i] = '\0';
				skyeye_printf("\n\rYes,master?");
				}
			}
	break;

	case '\b':				//backspace
		if ( i==0 ){		//has backed to first one
				//do nothing
			}
		else{
			i--;			//pointer back once
			skyeye_putc('\b');		//cursor back once
			skyeye_putc(' ');	      //earse last char in screen
			skyeye_putc('\b');		//cursor back again
			}
	break;
	
	case ' ':               //don't allow continuous or begin space(' ')
		if((CommandBuf[i-1] == ' ')||(i==0)||(i>MaxLenComBuf)){
				//do nothing
			}
		else{
			CommandBuf[i] = ch;
			i++;
			skyeye_putc(ch);  //display and store ch
			}
	break;

	default:				//normal key
		if (i>MaxLenComBuf){	//the buf reached MAX 
			//do nothing
			}			
		else{
			CommandBuf[i] = ch;
			i++;
			skyeye_putc(ch);  //display and store ch
			}
	break;
		}  //switch
	}//for(;;)
}

INT8U CommandAnalys(char *Buf)
{
INT8U i;
INT8U pointer;
INT8U num;
char name[20];		//command name length <20

 argc = 0;              //argc is global
 pointer = 0;
 num = 0;
skyeye_printf("\n\r");

while((Buf[pointer]!=' ') && (Buf[pointer]!='\0') && pointer<20 ){
	name[pointer]=Buf[pointer];
	pointer++;
	}
name[pointer] = '\0';	//now got the command name, and pointer is to the first space in the Buf

for(i=0;i<MAX_COMMAND_NUM;i++){
	if(!strcmp(name,ShellComms[i].name)){
		num = i;
		break;
		}				//find the command number
}					
						//not find it
if (i==MAX_COMMAND_NUM) return ERRORCOMMAND;
					
while(Buf[pointer]!='\0'){
	if(Buf[pointer]==' '){
		if(argc>0){
			Buf[pointer] = '\0';			//end of last argv
		}
		pointer++;
		argv[argc] = &Buf[pointer];			//add a parameter for every space
		argc++;
		}
	else{
		pointer++;
		}
	}//while

return num;
}
