/*	 
 *	commands.c
 *	the genie shell command part for ucosII
 *	under skyeye
 *
 *	Bugs report:	 Yang Ye  ( yangye@163.net )
 *	Last modified:	 2003-02-19 
 *
 */

#include "skyeye_stdio.h"
#include "includes.h"
#include "at91_init.h"
#include "commands.h"

command ShellComms[MAX_COMMAND_NUM];

INT8U InitCommands()
{
	ShellComms[0].num = 0;
	ShellComms[0].name = "hello";
	ShellComms[0].CommandFunc = HelloFunc;

	ShellComms[1].num = 1;
	ShellComms[1].name = "hostname";
	ShellComms[1].CommandFunc = HostNameFunc;
	return 0;
}

INT8U HelloFunc(INT8U argc,char **argv)
{
	int i;
	skyeye_printf("\n\rHello! I am genie");
	skyeye_printf("\n\ryour argv is :");
	if(argc>0){
	for(i=0;i<argc;i++){
		skyeye_printf("\n\r");
		skyeye_printf(argv[i]);
		}
  	}
	return 0;
}
		

INT8U HostNameFunc(INT8U argc,char **argv)
{
	skyeye_printf("\n\rHostname is genies");
	return 0;
}
