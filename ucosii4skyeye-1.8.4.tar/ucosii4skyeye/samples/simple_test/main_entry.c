/*   
 *  test.c
 *  this file implement start_kernel and irqhandler
 *  for Atmel AT91 operating system
 *
 *  Bugs report:     li ming  ( lmcs00@mails.tsinghua.edu.cn )
 *  Last modified:   2003-02-02 
 *
 */
 
#include "skyeye_stdio.h"
#include "at91_tc.h"
#include "at91_usart.h"
#include "at91_init.h"

/* just want to implement the function pointer for user_hook_isr */
extern void (* user_hook_isr) ( void ) ;

void my_test_isr(void)
{
	register volatile struct at91_timers* tt = (struct at91_timers*) (AT91_TC_BASE);
        register volatile struct at91_timer_channel* tc = &tt->chans[KERNEL_TIMER].ch;
	static int count = 0;
 
 	count++;
 	
 	if ( (count % 1000) == 0 )
        	skyeye_printf( "<my_test_isr> count = %d, timer count= %d\n", count/1000, tc->cv );
        return;
}


void install_irqhandler(void * isr);
void system_isr( void );

char s[100];
/*  this is a very simple kernel start, just a single process */
/*  you can add shell to it, so it can run more pleasing */
void start_kernel(void)
{
	static int count = 1;
	
	/* firstly, we should install time irq handler */
	install_irqhandler( system_isr );
	
	/* additionly, here user can add a hook isr */
	request_irq(5, my_test_isr);
	
	/* finally, we can start timer */
	at91_init();
	
	skyeye_printf( "start kernel ok!\n" );
	
	while( count++ )
		if ( count % 10000 == 0 )
		{
			skyeye_printf( "main %d: > \n", count/10000 );
			//skyeye_gets( s );
			//skyeye_printf( "your input: %s\n", s );
		}
}			

