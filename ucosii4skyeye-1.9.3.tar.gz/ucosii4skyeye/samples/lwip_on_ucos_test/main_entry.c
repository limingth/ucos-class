//#include "includes.h"

#include "lwip/debug.h"

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/pbuf.h"
#include "lwip/sys.h"

#include "lwip/tcpip.h"

#include "lwip/api.h"

#include "netif/arp.h"

#include "netif/loopif.h"
//yangye 2003-1-23
#include "netif/ne2kif.h"
#include "arch/sys_arch.h"
#include "skyeye_stdio.h"


extern struct netif *rtl8019if_netif;
struct RTL8019if *rtlif; 

extern void OSISR(void);
extern void OSTimeTick(void);
extern void ne2k_isr(void);
void at91_init_kernel(void);

#define 	PRINT	skyeye_printf

//chy 2003-01-23: a little big stack
#define	TASK_STK_SIZE	4096		// Stack size, in size of SO_STK, or int 
//yangye 2003-1-27

// task prio 1 for lwip init( it also init hardware and timer task )
OS_STK	lwip_init_stk[TASK_STK_SIZE];	// lwip stacks

// user task start from prio 3!!!!
OS_STK	     usr_stk[TASK_STK_SIZE];	// user Task stack

// Prototypes

void	usr_task(void * pParam);
void 	lwip_init_task(void *pParam);
void 	tcpip_init_done(void *arg);
void	Sleep(INT16U uSec);
void   tcpecho_init(void);


// Application entry point, invoked from Entry.obj
//chy:2003-05-21: get liming's advice, when I commit main fun, then arm-elf-tools-20030314 can pass it!
/*
int main(void)
{
	return 0;
}
*/
void abort(void)
{	
	return ;
}
void start_kernel(void)
{
       int     LineNo10 = 0;
	int     LineNo11 = 1;
	int     LineNo12 = 2;
	int     LineNo13 = 3;
	int     LineNo14 = 4;
	
	install_irqhandler(OSISR);
	request_irq(5,OSTimeTick);
	request_irq(16,ne2k_isr);

	OSInit();

	// Create two tasks.
	//yangye 2003-1-23
	//the timer is used in lwip
	//task 0 is created by lwip_init_task (it calls TmrInit() in tmr.c)

	//task 1 is lwip init task
	//it also init hardware and timer task!
	//OSTaskCreate(lwip_init_task, (void*)1, &lwip_init_stk[TASK_STK_SIZE-1], 1);	
	OSTaskCreate(lwip_init_task, &LineNo11, &lwip_init_stk[TASK_STK_SIZE-1], 0);	
	OSTaskCreate(usr_task,&LineNo12,&usr_stk[TASK_STK_SIZE-1],1);
	//task 2 is created by tcpip_init() in lwip_init_task
	//task 3 is user task
	//	OSTaskCreate(usr_task, &LineNo13, &user_stk[TASK_STK_SIZE-1], 3);
    	
	// Start multitasking.
      	OSStart();
	/* NEVER EXECUTED */
}

// Display a line of characters at the line specified by the parameter,
// assuming a color 80x25 video adapter.
//
// This function never returns.

void usr_task(void * pParam)
{
  PRINT("\nusr_task: hello!\n");
  while(1){
    Sleep(5);
  }
}

void lwip_init_task(void * pParam)
{
  struct ip_addr ipaddr, netmask, gw;
  sys_sem_t sem;
  
//yangye 2003-1-23
//move hardware init here!
  at91_init();

#ifdef STATS
  stats_init();
#endif /* STATS */
  sys_init();
  mem_init();
  memp_init();
  pbuf_init();
  PRINT("System initialized.\n");
   
//mainthread
  netif_init();
  sem = sys_sem_new(0);
  tcpip_init(tcpip_init_done, &sem);
  sys_sem_wait(sem);
  sys_sem_free(sem);
  PRINT("TCP/IP initialized.\n");
  
 
  //add loop interface
  IP4_ADDR(&gw, 127,0,0,1);
  IP4_ADDR(&ipaddr, 127,0,0,1);
  IP4_ADDR(&netmask, 255,0,0,0);
  
  netif_add(&ipaddr, &netmask, &gw, loopif_init,
	    tcpip_input);
	    
  //add ne2k interface
  IP4_ADDR(&gw, 10,0,0,1);
  IP4_ADDR(&ipaddr, 10,0,0,2);
  IP4_ADDR(&netmask, 255,255,255,0);
  
  netif_set_default(netif_add(&ipaddr, &netmask, &gw, ne2k_init,
			      tcpip_input));
  
  PRINT("Applications started.\n");
  
//we can add tcpip application here !
//yangye 2003-1-27
//notice :must use sys_thread_new() to add lwip tasks !!!
//OSTaskCreate(udpecho_thread, (void *)0x1111, &LwipStk1[TASK_STK_SIZE - 1], 6);
//  httpd_init();

   tcpecho_init();
  
  PRINT(" tcpecho created!");
  rtlif = rtl8019if_netif->state; //test!!!!!  

  /* Block for ever. */
  sem = sys_sem_new(0);
  sys_sem_wait(sem);
  PRINT(" never goes here, should not appear!");
}

void
tcpip_init_done(void *arg)
{
  sys_sem_t *sem;
  sem = arg;
  sys_sem_signal(*sem);
}


// Sleeps for the specified delay (in seconds).
// Since the 8254 is not set in this implementation,
// sleeping one second means sleeping 18 clock ticks.

void Sleep(INT16U uSec)
{
	OSTimeDly((INT16U) (uSec) * 10);
}








/*-----------------------------------------------------------------------------------*/
static void 
tcpecho_thread(void *arg)
{
  struct netconn *conn, *newconn;
  err_t err;

  /* Create a new connection identifier. */
  conn = netconn_new(NETCONN_TCP);

  /* Bind connection to well known port number 7. */
  netconn_bind(conn, NULL, 7);

  /* Tell connection to go into listening mode. */
  netconn_listen(conn);

  while(1) {

	/* Grab new connection. */
	newconn = netconn_accept(conn);
	/*printf("accepted new connection %p\n", newconn);*/
	/* Process the new connection. */
	if(newconn != NULL) {
	  struct netbuf *buf;
	  void *data;
	  u16_t len;
	  
	  while((buf = netconn_recv(newconn)) != NULL) {
	/*printf("Recved\n");*/
	do {
	  netbuf_data(buf, &data, &len);
	  err = netconn_write(newconn, data, len, NETCONN_COPY);
	  if(err != ERR_OK) {
		/*		printf("tcpecho: netconn_write: error \"%s\"\n", lwip_strerr(err));*/
	  }
	} while(netbuf_next(buf) >= 0);
	netbuf_delete(buf); 
	  }
	  /*printf("Got EOF, looping\n");*/
	  /* Close connection and discard connection identifier. */
	  netconn_delete(newconn);
	}
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcpecho_init(void)
{
  sys_thread_new(tcpecho_thread, NULL);  
}
/*-----------------------------------------------------------------------------------*/


